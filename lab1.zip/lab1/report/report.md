---
## Front matter
title: "Имитационное моделирование" 
subtitle: "Отчёт по первому блоку лабораторных работ"
author: "Лушин Артём Андреевич"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: false
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Приобретение навыков моделирования сетей передачи данных с помощью средства имитационного моделирования NS-2, а также анализ полученных результатов моделирования. 

# Выполнение лабораторной работы

1) Из лабораторной работы 1: в рабочем пространстве создали каталог для выполнения лабораторных работы, а затем создали файл shablon.tcl в котором будет находиться сам скрипт. 

![Создание shablon.tcl](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/1.jpg){#fig:001 width=70%}

2) В файле написали скрипт. Создали объект, задали переменную, которая записывает входные данные. Создали переменную для записи трассировки. Добавили процедуру завершения и указали, что финиш нужно запускать через 5 секунд после начала моделирования. 

![Скрипт 1](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/2.jpg){#fig:002 width=70%} 

3) Запустили наш скрипт и посмотрели результат вывода. 

![Запуск скрипта 1](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/3.jpg){#fig:003 width=70%}

![Результат работы скрипта 1](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/4.jpg){#fig:004 width=70%}

4) Скопировали содержимое файла в новый файл. 

![Копирование файла](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/5.jpg){#fig:005 width=70%}

5) В новый файл добавили описание топологии. Создали агента для приёма и генерации трафика. Создали агента, который работает как приёмник. Соединили агентов. 

![Скрипт 2](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/6.jpg){#fig:006 width=70%}

6) Сохранили файл и запустили второй скрипт.

![Запуск скрипта 2](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/7.jpg){#fig:007 width=70%}

![Результат работы скрипта 2](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/8.jpg){#fig:008 width=70%} 

7) Создал 4 узла и 3 дуплексных соединения с указанием направления. Создал агента с прикреплённым к нему источником CBR и агент с прикреплённым к нему приложением FTP. Создал агента-получателя. Соединила агентов и получателей. Задал цвет каждого потока. 

![Скрипт 3](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/9.jpg){#fig:009 width=70%}

8) Сохранил и запустил скрипт 3. 

![Запуск скрипта 3](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/10.jpg){#fig:010 width=70%} 

![Результат работы скрипта 3](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/11.jpg){#fig:011 width=70%}

9) Вновь скопировал шаблон и создал новый файл.

![Создание нового файла](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/12.jpg){#fig:012 width=70%}

10) Описал топологию моделируемой сети. Соединил узлы так, чтобы создать круговую топологию. Задал передачу данных от узла 0 к узлу 3. Добавил команды разрыва соединения между узлами 1 и 2 на одну секунду, а также время начала и окончания передачи данных.

![Скрипт 4](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/13.jpg){#fig:013 width=70%}

11) Запустил скрипт и посмотрел результат работы. 

![Скрипт 4. Передача данных](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/14.jpg){#fig:014 width=70%} 

![Скрипт 4. Обрыв соединения](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/15.jpg){#fig:015 width=70%} 

![Скрипт 4. Альтернативный маршрут](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/16.jpg){#fig:016 width=70%} 

12) Ещё раз скопировал содержимое шаблона и создал новый файл.

![Копирование шаблона](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/17.jpg){#fig:017 width=70%}

13) Создал 5 узлов и соединил их так, чтобы создать круговую топологию. Создал ещё один узел и соединил с узлом 1. Задал передачу данных от узла 0 к узлу 5. СОздал агента с прикреплённым к нему приложением FTP. Создал агента-получателя. Соединил агента и получателя. Добавил команду разрыва соединения между 0 и 1 узлом на одну секунду, а также время начала и окончания передачи данных. 

![Скрипт 5](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/18.jpg){#fig:018 width=70%}

14) Сохранил и запустил 5 скрипт. Посмотрел на результат работы. 

![Запуск скрипта](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/19.jpg){#fig:019 width=70%} 

![Скрипт 5: Передача данных](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/20.jpg){#fig:020 width=70%} 

![Скрипт 5: Обрыв связи](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/21.jpg){#fig:021 width=70%} 

![Скрипт 5: Альтернативный маршрут](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/22.jpg){#fig:022 width=70%}

15) Из лабораторной работы 2: Создали файл для работы. 

![Создание файла для 2 лабораторной](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/23.jpg){#fig:023 width=70%}

16) Внёс в файл скрипт из представленной работы на ТУИС. 

![Скрипт 6](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/24.jpg){#fig:024 width=70%} 

17) После сохранения скрипта запустил его и посмотрел результаты. 

![Скрипт 6: График изменения очереди](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/25.jpg){#fig:025 width=70%}

![Скрипт 6: График изменения окна](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/26.jpg){#fig:026 width=70%}

18) В файле изменил тип протокола с Reno на NewReno.

![Скрипт 7](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/27.jpg){#fig:027 width=70%} 

19) После изменений запустил скрипт и посмотрел результаты. 

![Скрипт 7: График изменения окна](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/28.jpg){#fig:028 width=70%}

![Скрипт 7: График изменения очереди](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/29.jpg){#fig:029 width=70%}

20) Вновь в файле изменили тип протокола с NewReno на Vegas.

![Скрипт 8](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/30.jpg){#fig:030 width=70%} 

21) Сохранил изменения в скрипте и посмотрел на результаты работы. 

![Скрипт 8: График изменения очереди](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/31.jpg){#fig:031 width=70%} 

22) Внёс изменения при отображении окон с графиками. 

![Скрипт 9](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/32.jpg){#fig:032 width=70%} 

![Скрипт 9: Новые графики](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/33.jpg){#fig:033 width=70%} 

23) Из лабораторной работы 3: создали новый файл для работы. 

![Создание файла для 3 лабораторной](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/34.jpg){#fig:034 width=70%}

24) Взял код из текста и заполнил новый файл. 

![Скрипт 10](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/35.jpg){#fig:035 width=70%}

25) В рабочем каталоге создал файл graph_plot и внёс туда скрипт из работы. 

![Скрипт 11](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/36.jpg){#fig:036 width=70%} 

26) Запустил файлы и посмотрел на результат работы скрипта 10 и 11.

![Запуск файлов](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/37.jpg){#fig:037 width=70%} 

![Результат скрипта 10 и 11](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/38.jpg){#fig:038 width=70%} 

27) Из лабораторной работы 4: Заполнил исполняемый файл в соответствии с заданием. 

![Скрипт 12](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/39.jpg){#fig:039 width=70%}

28) Запустил скрипт и посмотрел на результат работы. Получил модель сети в nam, график изменения размера окна, график изменения длины очереди и средней длины очереди на первом маршрутизаторе. 

![Скрипт 12: Модель сети](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/40.jpg){#fig:040 width=70%} 

![Скрипт 12: График изменения средней длины очереди](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/41.jpg){#fig:041 width=70%} 

![Скрипт 12: График изменения длины очереди](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/42.jpg){#fig:042 width=70%} 

![Скрипт 12: График изменения окна](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/43.jpg){#fig:043 width=70%} 

![Скрипт 12: График изменения окна на 1 источнике](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/44.jpg){#fig:044 width=70%} 

29) Создал новый файл и заполнил его для создания графиков в Plot. 

![Скрипт 13](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/45.jpg){#fig:045 width=70%}

30) Запустил файл и посмотрел на графики, которые получились. 

![Скрипт 13: График изменения окна на 1 источнике](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/46.jpg){#fig:046 width=70%} 

![Скрипт 13: График изменения окна](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/47.jpg){#fig:047 width=70%} 

![Скрипт 13: График изменения длины очереди](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/48.jpg){#fig:048 width=70%} 

![Скрипт 13: График изменения средней длины](/home/aalushin1/study_2025-2026_mip/labs/lab1/report/image/49.jpg){#fig:049 width=70%} 

# Вывод 

Я приобрёл навыки моделирования сетей передачи данных с помощью средства имитационного моделирования NS-2, а также проанализировал полученные результаты моделирования. 

